"use strict";

const assert = require("node:assert/strict");
const {
  calculateStatistics,
  formatNumber,
  isIntegerInput,
} = require("./statistics");

assert.deepEqual(calculateStatistics([8, 2, 5]), {
  mean: 5,
  median: 5,
  count: 3,
  minimum: 2,
  maximum: 8,
});

assert.deepEqual(calculateStatistics([-4, 10, 2, 8]), {
  mean: 4,
  median: 5,
  count: 4,
  minimum: -4,
  maximum: 10,
});

assert.equal(isIntegerInput("-12"), true);
assert.equal(isIntegerInput("3.5"), false);
assert.equal(isIntegerInput("hello"), false);
assert.equal(isIntegerInput("999999999999999999999"), false);
assert.equal(formatNumber(6.6666666667), "6.67");
assert.equal(formatNumber(8), "8");
assert.throws(() => calculateStatistics([]), /At least one integer/);

console.log("All automated tests passed.");
