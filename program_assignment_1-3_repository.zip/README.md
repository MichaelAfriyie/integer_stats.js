# Program Assignment 1-3

This repository contains a Node.js console program that accepts integers until the user enters `q`, then displays the mean, median, count, minimum, and maximum. Invalid entries are rejected without ending the program.

## Run the program

```text
node statistics.js
```

## Run the automated checks

```text
node statistics.test.js
```

## Assignment evidence

The `screenshots` folder contains the local evidence already prepared for the assignment:

- the complete program source (two images),
- a successful Node.js run that also shows invalid-input handling, and
- the local Git commit history.

After pushing this repository, add two more screenshots to that folder: the GitHub repository showing the program and the repository collaborators page showing the instructor. Then commit and push those images so the complete screenshot package is also stored on GitHub.

## GitHub steps that require the student's account

1. Create a new GitHub repository for the course.
2. Add that repository as `origin` and push the `main` branch.
3. In repository settings, add the instructor using the identifier stated in the assignment (`mcgarrym@vcu`). Confirm the exact GitHub username with the instructor if GitHub does not recognize it.
4. Capture the GitHub repository and collaborators screenshots; the local code, Node, and `git log` images are already in `screenshots`.
5. Add the two GitHub screenshots to `screenshots`, then commit and push them.

Never place a personal access token in this repository or in a screenshot.
