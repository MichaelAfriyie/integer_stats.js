"use strict";

const readline = require("node:readline");

/**
 * Calculates the requested statistics for a non-empty array of integers.
 * A sorted copy is used so the caller's original array is not changed.
 */
function calculateStatistics(numbers) {
  if (!Array.isArray(numbers) || numbers.length === 0) {
    throw new Error("At least one integer is required.");
  }

  const sorted = [...numbers].sort((a, b) => a - b);
  const count = sorted.length;
  const sum = sorted.reduce((total, value) => total + value, 0);
  const middle = Math.floor(count / 2);
  const median =
    count % 2 === 1
      ? sorted[middle]
      : (sorted[middle - 1] + sorted[middle]) / 2;

  return {
    mean: sum / count,
    median,
    count,
    minimum: sorted[0],
    maximum: sorted[count - 1],
  };
}

/** Returns true only for a complete base-10 integer that JavaScript can store safely. */
function isIntegerInput(value) {
  const normalized = value.trim();
  return /^[+-]?\d+$/.test(normalized) && Number.isSafeInteger(Number(normalized));
}

/** Keeps whole numbers clean and rounds repeating decimals for readable output. */
function formatNumber(value) {
  return Number.isInteger(value) ? String(value) : value.toFixed(2);
}

/** Starts the interactive console program. */
function runProgram() {
  const numbers = [];
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  console.log("Integer Statistics Calculator");
  console.log('Enter one integer at a time. Enter "q" when finished.\n');

  const askForInteger = () => {
    rl.question("Integer (or q to quit): ", (answer) => {
      const input = answer.trim();

      if (input.toLowerCase() === "q") {
        if (numbers.length === 0) {
          console.log("No integers were entered, so no statistics can be calculated.");
        } else {
          const results = calculateStatistics(numbers);
          console.log("\nResults");
          console.log(`Numbers entered: ${numbers.join(", ")}`);
          console.log(`Mean: ${formatNumber(results.mean)}`);
          console.log(`Median: ${formatNumber(results.median)}`);
          console.log(`Count: ${results.count}`);
          console.log(`Minimum value: ${results.minimum}`);
          console.log(`Maximum value: ${results.maximum}`);
        }

        rl.close();
        return;
      }

      if (!isIntegerInput(input)) {
        console.log(
          'Invalid entry. Enter a whole integer within JavaScript\'s safe range, or "q" to quit.'
        );
      } else {
        numbers.push(Number(input));
        console.log(`Accepted: ${input}`);
      }

      askForInteger();
    });
  };

  askForInteger();
}

if (require.main === module) {
  runProgram();
}

module.exports = { calculateStatistics, formatNumber, isIntegerInput };
