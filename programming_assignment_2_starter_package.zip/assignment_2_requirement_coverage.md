# Programming Assignment 2 Requirement Coverage

This file maps the assignment requirements to the work you should submit.

| Assignment Requirement | Covered By |
| --- | --- |
| Prompt the user for integers until `q` is entered | `product_condition_checker.js` prompt loop |
| Recognize capital `Q` as quit | `trimmedAnswer.toLowerCase() === "q"` |
| Echo integers back to the user | `Integers entered:` output |
| Determine whether two entered integers multiply to a third entered integer | `findProductMatch(values)` |
| Show condition met message | `Condition is met: a x b = c` |
| Show condition not met message | `Condition was not met` |
| Support 0 to n integers | Empty list and short list handling in `finishProgram()` |
| Display error for invalid input | Invalid input check before pushing to `numbers` |
| Include comments explaining the code | Comment above the match-checking loop |
| Program works in Node | Run with `node product_condition_checker.js` |
| Screenshot with two or less integers | Use Case A from the screenshot guide |
| Screenshot with condition met | Use Case B from the screenshot guide |
| Screenshot with condition not met | Use Case C from the screenshot guide |
| GitHub collaborator requirement | Confirm instructor username `mcgarrymvcu` is added as a collaborator |
| Confirm local repo is linked to GitHub | Screenshot `git remote -v` |
| Pull from GitHub repository | Screenshot `git pull origin main` |
| Create branch named `new-feature` | Screenshot `git checkout -b new-feature` |
| Add program to new branch | Screenshot file added/committed while on `new-feature` |
| Commit with appropriate message | Screenshot commit output or `git log` |
| Merge branch into main | Screenshot `git merge new-feature` |
| Push main branch to GitHub | Screenshot `git push origin main` |
| View Git history | Screenshot `git log --oneline --graph --all` |
| GitHub repository showing the program | Screenshot repo page with `.js` file visible |

Before submitting, check that your screenshot package includes every row above. The code is only 60 points; the Git and GitHub proof are the other 40 points, so do not skip the repository screenshots.
