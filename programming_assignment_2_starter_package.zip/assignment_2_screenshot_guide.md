# Programming Assignment 2 Screenshot Guide

Use this as your screenshot plan so every required item is covered.

## 1. Program Code

Take a screenshot of `product_condition_checker.js` open in your editor.

Make sure the screenshot shows:
- The prompt loop.
- The `q` / `Q` quit check.
- The invalid input error message.
- The product-checking function.
- Code comments.

## 2. Program Runs Successfully in Node

Run the program with:

```bash
node product_condition_checker.js
```

Capture these separate runs.

### Case A: Two or Less Integers

Input:

```text
5
8
q
```

Expected ending:

```text
Integers entered:
5, 8
Condition was not met
```

### Case B: Condition Is Met

Input:

```text
3
27
4
9
q
```

Expected ending:

```text
Integers entered:
3, 27, 4, 9
Condition is met: 3 x 9 = 27
```

### Case C: Condition Is Not Met

Input:

```text
3
28
4
9
q
```

Expected ending:

```text
Integers entered:
3, 28, 4, 9
Condition was not met
```

### Case D: Error Handling and Capital Q

Input:

```text
hello
12
Q
```

Expected ending:

```text
Error: please enter an integer or q to quit.
Integers entered:
12
Condition was not met
```

This extra screenshot helps prove the error handling and capital `Q` requirement.

## 3. Git Commands

Take screenshots showing these commands and their output:

```bash
git remote -v
git pull origin main
git checkout -b new-feature
git add product_condition_checker.js
git commit -m "Add product condition checker"
git checkout main
git merge new-feature
git log --oneline --graph --all
git push origin main
```

If your repository is not linked yet, run this before the pull:

```bash
git remote add origin <URL of your GitHub repository>
```

## 4. GitHub Repository

Take a screenshot of your GitHub repository page after pushing.

Make sure the screenshot shows:
- The repository name.
- `product_condition_checker.js` listed in the files.
- The latest commit showing your program was added.

## 5. Submission Reminder

Your instructor specifically says repositories without the `.js` program receive a zero, so confirm that the JavaScript file is visible on GitHub before submitting.
