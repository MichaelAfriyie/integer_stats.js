const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const numbers = [];

function askForInput() {
  rl.question("Enter an integer, or q to quit: ", (answer) => {
    const trimmedAnswer = answer.trim();

    // The assignment says both q and Q should quit the program.
    if (trimmedAnswer.toLowerCase() === "q") {
      finishProgram();
      return;
    }

    // Only whole-number input is accepted. Anything else gets an error message.
    if (!/^[-+]?\d+$/.test(trimmedAnswer)) {
      console.log("Error: please enter an integer or q to quit.");
      askForInput();
      return;
    }

    numbers.push(Number(trimmedAnswer));
    askForInput();
  });
}

function finishProgram() {
  console.log("\nIntegers entered:");

  // Echo the numbers back so the user can see exactly what was checked.
  if (numbers.length === 0) {
    console.log("No integers were entered.");
  } else {
    console.log(numbers.join(", "));
  }

  const match = findProductMatch(numbers);

  if (match) {
    console.log(`Condition is met: ${match.first} x ${match.second} = ${match.product}`);
  } else {
    console.log("Condition was not met");
  }

  rl.close();
}

function findProductMatch(values) {
  // A valid match needs two entered integers whose product equals a third entered integer.
  for (let firstIndex = 0; firstIndex < values.length; firstIndex++) {
    for (let secondIndex = firstIndex + 1; secondIndex < values.length; secondIndex++) {
      const product = values[firstIndex] * values[secondIndex];

      for (let thirdIndex = 0; thirdIndex < values.length; thirdIndex++) {
        if (
          thirdIndex !== firstIndex &&
          thirdIndex !== secondIndex &&
          values[thirdIndex] === product
        ) {
          return {
            first: values[firstIndex],
            second: values[secondIndex],
            product,
          };
        }
      }
    }
  }

  return null;
}

askForInput();
